-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mar 02, 2021 alle 18:09
-- Versione del server: 10.4.17-MariaDB
-- Versione PHP: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `societa_turistica`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `competenze`
--

CREATE TABLE `competenze` (
  `id_guida` int(11) NOT NULL,
  `lingua_conosciuta` varchar(11) NOT NULL,
  `liv_conoscenza` varchar(22) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `competenze`
--

INSERT INTO `competenze` (`id_guida`, `lingua_conosciuta`, `liv_conoscenza`) VALUES
(1, 'eng', '3'),
(2, 'ing', 'avanzata'),
(3, 'fra', 'avanzata'),
(4, 'fra', 'avanzata');

-- --------------------------------------------------------

--
-- Struttura della tabella `eventi`
--

CREATE TABLE `eventi` (
  `id_visita` int(11) NOT NULL,
  `id_gruppo` int(11) NOT NULL,
  `prezzo` int(11) NOT NULL,
  `id_evento` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struttura della tabella `gruppi`
--

CREATE TABLE `gruppi` (
  `id_gruppo` int(11) NOT NULL,
  `max_partecipanti` int(11) NOT NULL,
  `min_partecipanti` int(11) NOT NULL,
  `id_guida` int(11) NOT NULL,
  `data_pagamento` varchar(11) NOT NULL,
  `tipo_pagamento` varchar(11) NOT NULL,
  `desc_pagamento` varchar(11) NOT NULL,
  `id_evento` int(11) NOT NULL,
  `id_utente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struttura della tabella `guida`
--

CREATE TABLE `guida` (
  `id_guida` int(11) NOT NULL,
  `nome` varchar(11) NOT NULL,
  `sesso` varchar(11) NOT NULL,
  `data_nascita` varchar(20) NOT NULL,
  `titolo_studio` varchar(30) NOT NULL,
  `anno_conseguimento` varchar(30) NOT NULL,
  `lingua_madre` varchar(22) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `guida`
--

INSERT INTO `guida` (`id_guida`, `nome`, `sesso`, `data_nascita`, `titolo_studio`, `anno_conseguimento`, `lingua_madre`) VALUES
(1, 'marco', 'm', '16/11/1994', 'laurea', '16/11/2002', ''),
(2, 'luigi', 'm', '16/11/1994', 'laurea', '16/11/2006', ''),
(3, 'federica', 'f', '16/11/1994', 'laurea', '16/11/2005', ''),
(4, 'manuela', 'f', '16/11/1994', 'laurea', '16/11/2001', ''),
(5, 'roberto', 'm', '16/11/1994', 'diploma', '16/11/2000', '');

-- --------------------------------------------------------

--
-- Struttura della tabella `unione`
--

CREATE TABLE `unione` (
  `id_utente` int(11) NOT NULL,
  `id_gruppo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struttura della tabella `visita`
--

CREATE TABLE `visita` (
  `id_visita` int(10) NOT NULL,
  `durata _media` varchar(10) NOT NULL,
  `luogo` varchar(10) NOT NULL,
  `nome_visita` varchar(10) NOT NULL,
  `data` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `visita`
--

INSERT INTO `visita` (`id_visita`, `durata _media`, `luogo`, `nome_visita`, `data`) VALUES
(0, '', '', '', '20/03/2021'),
(100, '30min', 'roma', 'roma1', ''),
(200, '30min', 'roma', 'roma2', ''),
(300, '40min', 'milano', 'milano1', ''),
(400, '40min', 'milano', 'milano2', ''),
(500, '30min', 'milano', 'milano3', '20/03/2021');

-- --------------------------------------------------------

--
-- Struttura della tabella `visitatori`
--

CREATE TABLE `visitatori` (
  `id_utente` int(11) NOT NULL,
  `nome` varchar(11) NOT NULL,
  `cognome` varchar(11) NOT NULL,
  `nazionalità` varchar(11) NOT NULL,
  `lingua` varchar(11) NOT NULL,
  `e-mail` varchar(11) NOT NULL,
  `telefono` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `visitatori`
--

INSERT INTO `visitatori` (`id_utente`, `nome`, `cognome`, `nazionalità`, `lingua`, `e-mail`, `telefono`) VALUES
(1, 'lorenzo', 'nunzi', 'ita', 'ita', 'ita@òita-it', 325325342),
(111, '', '', '', '', '', 0);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `competenze`
--
ALTER TABLE `competenze`
  ADD UNIQUE KEY `id_guida` (`id_guida`);

--
-- Indici per le tabelle `eventi`
--
ALTER TABLE `eventi`
  ADD PRIMARY KEY (`id_visita`,`id_gruppo`,`id_evento`),
  ADD KEY `id_gruppo` (`id_gruppo`);

--
-- Indici per le tabelle `gruppi`
--
ALTER TABLE `gruppi`
  ADD PRIMARY KEY (`id_gruppo`,`id_guida`,`id_evento`,`id_utente`),
  ADD KEY `id_guida` (`id_guida`),
  ADD KEY `id_utente` (`id_utente`);

--
-- Indici per le tabelle `guida`
--
ALTER TABLE `guida`
  ADD PRIMARY KEY (`id_guida`);

--
-- Indici per le tabelle `unione`
--
ALTER TABLE `unione`
  ADD PRIMARY KEY (`id_utente`,`id_gruppo`),
  ADD KEY `id_gruppo` (`id_gruppo`);

--
-- Indici per le tabelle `visita`
--
ALTER TABLE `visita`
  ADD PRIMARY KEY (`id_visita`);

--
-- Indici per le tabelle `visitatori`
--
ALTER TABLE `visitatori`
  ADD PRIMARY KEY (`id_utente`);

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `competenze`
--
ALTER TABLE `competenze`
  ADD CONSTRAINT `competenze_ibfk_1` FOREIGN KEY (`id_guida`) REFERENCES `guida` (`id_guida`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `eventi`
--
ALTER TABLE `eventi`
  ADD CONSTRAINT `eventi_ibfk_1` FOREIGN KEY (`id_visita`) REFERENCES `visita` (`id_visita`),
  ADD CONSTRAINT `eventi_ibfk_2` FOREIGN KEY (`id_gruppo`) REFERENCES `gruppi` (`id_gruppo`);

--
-- Limiti per la tabella `gruppi`
--
ALTER TABLE `gruppi`
  ADD CONSTRAINT `gruppi_ibfk_1` FOREIGN KEY (`id_guida`) REFERENCES `competenze` (`id_guida`),
  ADD CONSTRAINT `gruppi_ibfk_2` FOREIGN KEY (`id_utente`) REFERENCES `unione` (`id_utente`);

--
-- Limiti per la tabella `unione`
--
ALTER TABLE `unione`
  ADD CONSTRAINT `unione_ibfk_1` FOREIGN KEY (`id_utente`) REFERENCES `visitatori` (`id_utente`),
  ADD CONSTRAINT `unione_ibfk_2` FOREIGN KEY (`id_gruppo`) REFERENCES `gruppi` (`id_gruppo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
